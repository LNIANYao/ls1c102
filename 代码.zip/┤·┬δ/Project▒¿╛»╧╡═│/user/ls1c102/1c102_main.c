#include "ls1x.h"
#include "Config.h"
#include "ls1x_gpio.h"
#include "ls1x_latimer.h"
#include "ls1x_string.h"
#include "ls1c102_ptimer.h"
#include "ls1c102_interrupt.h"

#define Key  GPIO_PIN_36

uint8_t receive_flag=0;
extern uint8_t receive_buf[];
extern bool flag_;
int main(int arg, char *args[])
{
    timer_init(1);
    Uart_init();
    while(1)
    {
        //if(receive_flag==1)
        //{
            //receive_flag=0;
            while(Key==1)
            {
                gpio_write_pin(13,0);
                gpio_write_pin(18,1);
            }
            
            if(strncmp(receive_buf,"1",1)==0)
            {
                gpio_write_pin(13,1);
                delay_ms(200);
                gpio_write_pin(13,0);
                delay_ms(200);
                gpio_write_pin(13,1);
                delay_ms(200);
                gpio_write_pin(13,0);
                delay_ms(200);
                gpio_write_pin(18,0);
            }
            if(strncmp(receive_buf,"0",1)==0)
            {
                gpio_write_pin(13,0);
                delay_ms(500);
                gpio_write_pin(18,1);
                
            }
        //}
            //delay_ms(300);
         
        //UART_SendData(UART0,1+0x30);
        //delay_ms(300);

    }
    return 0;
}

