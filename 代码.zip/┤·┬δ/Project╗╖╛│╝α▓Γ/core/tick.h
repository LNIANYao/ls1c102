/*
 * tick.h
 *
 * created: 2024/6/21
 *  author: 
 */

#ifndef _TICK_H
#define _TICK_H


#define TICKS_PER_SECOND    1000;
unsigned int get_clock_ticks(void);
int gpio_read(int gpio);
void ls1c102_ticker_isr(int vector, void *arg);
void Clock_initialize(void);
void delay_us(unsigned int us);
void delay_ms(unsigned int ms);


#ifdef __cplusplus
extern "C" {
#endif



#ifdef __cplusplus
}
#endif

#endif // _TICK_H

